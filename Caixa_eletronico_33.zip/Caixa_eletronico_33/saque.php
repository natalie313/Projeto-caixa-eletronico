<?php
    header('Content-type: text/html; charset=utf8');
    
    echo"
    <style>
    *{
        border: 0;
        margin: 0;
        box-sizing:border-box;
        font-family:Arial;
    }
    
    h1{
        color:rgb(69, 69, 219);
        text-shadow:2px 2px 4px gray;
        font-size:30pt;
        padding-left:10px;
        text-align:center;
    }

    h3{
        font-size:20pt;
        padding-left:10px;
        text-align:center;
    }

    p{
        font-size:15pt;
        padding-left:10px;
        padding-top:5px;
        text-align:center;
    }

    section{
        display:flex;
        justify-content:center;
        flex-wrap:wrap;
    }

    img{
        width:400px;
    }

    .valores{
        margin:0px 15px 20px 0px;
        text-align:center;
    }

    button{
        background:rgb(59, 200, 255);
        border-radius:5px;
        height:40px;
        width:100px;
        margin-left:30px;
    }

    button a{
        font-size:16pt;
        color:white;
        text-decoration:none;
    }

    </style>";
    
    //teste se preencheu o formulario
    if(isset($_POST["escolher"]) && !empty($_POST["escolher"])
    && isset ($_POST["agencia"]) && !empty($_POST["agencia"])
    && isset ($_POST["conta"]) && !empty($_POST["conta"])
    && isset ($_POST["senha"]) && !empty($_POST["senha"])
    && isset ($_POST["valor"]) && !empty($_POST["valor"])){

    $escolher = $_POST["escolher"];
    $agencia = $_POST["agencia"];
    $conta = $_POST["conta"];
    $senha = $_POST["senha"];
    $dinheiro = $_POST["valor"];
    $cont = 0;
  
    echo "<br><h1>Caixa eletrônico</h1>";
    echo "<br> <h3>Informações:</h3>";

    echo "<br><p> Banco: " .$escolher."</p>";
    echo "<br><p> Agencia: " .$agencia."</p>";
    echo "<br><p> Conta: ".$conta."</p>";
    echo "<br><p> Senha: ".$senha."</p>";
    echo "<br><p> Dinheiro: ".$dinheiro."</p>";
    echo"<br><br>";


    echo "<section>";

    if($dinheiro / 100 != 0){
      
        echo"<div class='valores'>";
        echo"<img src='img/100reais.jpg'><br>";

        for($i = 1; $i<= $dinheiro/100; $i++){   
            $cont++;
        }

        echo"<p>$cont</p></div>";

        $dinheiro -= ($i -1)*100;
       
        if($dinheiro/ 50 != 0){
            $cont = 0;
            echo"<div class='valores'>";
            echo"<img src='img/50reais.jpg'><br>";
            for($i = 1; $i<= $dinheiro/50; $i++){
                $cont++;
            }

            echo"<p>$cont</p></div>";
        }
       
      $dinheiro -= ($i -1)*50;

        if($dinheiro/ 20 != 0){
            $cont = 0;
            echo"<div class='valores'>";
            echo"<img src='img/20reais.jpg'><br>";
            for($i = 1; $i<= $dinheiro/20; $i++){
                $cont ++;
            }

            echo"<p>$cont</p> </div>";
        }
       
        $dinheiro -= ($i -1)*20;
        
        if($dinheiro/10 != 0){
            $cont=0;
            echo"<div class='valores'>";
            echo"<img src='img/10reais.jpg'><br>";
            for($i = 1; $i<= $dinheiro/10; $i++){
                $cont++;
            } 
            echo"<p>$cont</p> </div>";
        }


        $dinheiro -= ($i -1)*10;
        
        if($dinheiro/5 != 0){
            $cont=0;
            echo"<div class='valores'>";
            echo"<img src='img/5reais.jpg'><br>";
            for($i = 1; $i<= $dinheiro/5; $i++){
                $cont++;
            } 
            echo"<p>$cont</p></div>";
        }
       
        $dinheiro -= ($i -1)*5;
        
        if($dinheiro/2 != 0){
            $cont=0;
            echo"<div class='valores'>";
            echo"<img src='img/2reais.jpg'><br>";
            for($i = 1; $i<= $dinheiro/2; $i++){
               $cont++;
            }
            
            echo"<p>$cont</p></div>";
        }
       
        $dinheiro -= ($i -1)*2;
        
        if($dinheiro/1 != 0){
            $cont=0;          
            echo"<div class='valores'>";
            echo"<img src='img/1real.jpg'><br>";
            for($i = 1; $i<= $dinheiro/1; $i++){  
                $cont++;
            } 

            echo"<p>$cont</p></div>";
        }
    }
    echo "</section>";
}   
else{
     header("location: index.html");
}

echo"<br><button><a href='index.html'>Voltar</a></button>";

?>